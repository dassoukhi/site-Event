/*
FIchier : Creation_GroupeQ.sql
Auteurs : 
Dassoukhi Saleh 21613755
Fontaine Quentin 21611404
Prud'Homme Gateau Sebastien 21712267
Nom du groupe : Q
*/

DROP DATABASE IF EXISTS EVENT;